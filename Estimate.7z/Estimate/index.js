
exports.handler = function(event,context,callback){
    
var d = new Date();
var n = d.toISOString();
console.log("UTC time ****************",n);
var estDeliveryTime;
var utcTime = new Date();
 // utcTime.setHours(utcTime.getHours() + utcTime.getTimezoneOffset()/60 - 0);
  var year = utcTime.getFullYear()
  var month = addZero(utcTime.getMonth()+1);
  var day = addZero(utcTime.getDate());
  var hours = addZero(utcTime.getHours());
  var minutes = addZero(utcTime.getMinutes()+30);
 var seconds = addZero(utcTime.getSeconds());
  var miliSeconds = addZero(utcTime.getMilliseconds());
if(minutes>59){
var hours1 = addZero(utcTime.getHours()+1);
if (hours1>23){
 hours1=00;
 day=addZero(utcTime.getDate()+1);
}

var minutes1 = addZero(5);
console.log("hour from if minute >59 condition",hours1);
console.log("minutes from if minute >59 condition",minutes1);
 estDeliveryTime = year + "-" + month + "-"+ day + "T" + hours1 + ":" + minutes1+ ":" + seconds + "." + miliSeconds+"000Z";
console.log("estimate DeliveryTime is ",estDeliveryTime);
}

else{
 estDeliveryTime = year + "-" + month + "-"+ day + "T" + hours + ":" + minutes+ ":"+ seconds + "."+ miliSeconds +"000Z";
console.log("estimate DeliveryTime is ",estDeliveryTime); //"2020-10-01T18:20:42.395Z"
}
  function addZero(n) {
      // add a leading zero if time digit only has one digit
      return ( n < 0 || n > 9 ? "" : "0" ) + n;
  };



let req = event;
//console.log('request body is: ',req);

var dropoff_address = req.dropoff_address;
//var dropoff_address = event.request.dropoff_address;
//console.log("The dropoff_address is =>>>>>>>",dropoff_address);

var dropoff_address_city = dropoff_address.city;
var dropoff_address_state = dropoff_address.state;
var dropoff_address_street = dropoff_address.street;
var dropoff_address_zip = dropoff_address.zip_code;
var dropoff_address_unit = dropoff_address.unit;

try{
console.log("event is",event);
const estimates = `{


        "delivery_time": "${estDeliveryTime}",
        "pickup_window_start_time": null,
        "fee": 2000,
        "dropoff_address": {
            "city": "${dropoff_address_city}",
            "dasher_parking_details": null,
            "state": "${dropoff_address_state}",
            "street": "${dropoff_address_street}",
            "unit": "${dropoff_address_unit}",
            "zip_code": "${dropoff_address_zip}"
        },
        "pickup_time": "${n}",
        "currency": "USD",
        "pickup_window_end_time": null,
        "id": 1
    



}`;


           callback(null,JSON.parse(estimates)) ;
   }
    
    catch(e){
    callback(new Error("Error: failed to get response!"));
  }

};


