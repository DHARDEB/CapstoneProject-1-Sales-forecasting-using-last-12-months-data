exports.handler = function(event,context,callback){

var d = new Date();
var updated_at = d.toISOString();
console.log('updated_at is: ',updated_at);
var timestamp = updated_at.slice(0, -1) // delete last letter 'Z'
console.log('timestamp is: ',timestamp);

var d = new Date();
var n = d.toISOString();
console.log("UTC time ****************",n);
var estDeliveryTime;
var utcTime = new Date();
 // utcTime.setHours(utcTime.getHours() + utcTime.getTimezoneOffset()/60 - 0);
  var year = utcTime.getFullYear()
  var month = addZero(utcTime.getMonth()+1);
  var day = addZero(utcTime.getDate());
  var hours = addZero(utcTime.getHours());
  var minutes = addZero(utcTime.getMinutes()+30);
 var seconds = addZero(utcTime.getSeconds());
  var miliSeconds = addZero(utcTime.getMilliseconds());
if(minutes>59){
var hours1 = addZero(utcTime.getHours()+1);
var minutes1 = addZero(5);
console.log("hour from if minute >59 condition",hours1);
console.log("minutes from if minute >59 condition",minutes1);
 estDeliveryTime = year + "-" + month + "-"+ day + "T" + hours1 + ":" + minutes1+ ":" + seconds + "." + miliSeconds+"000Z";
console.log("estimate DeliveryTime is ",estDeliveryTime);
}
else{
 estDeliveryTime = year + "-" + month + "-"+ day + "T" + hours + ":" + minutes+ ":"+ seconds + "."+ miliSeconds +"000Z";
console.log("estimate DeliveryTime is ",estDeliveryTime); //"2020-10-01T18:20:42.395Z"
}
  function addZero(n) {
      // add a leading zero if time digit only has one digit
      return ( n < 0 || n > 9 ? "" : "0" ) + n;
  };

let req = event;
//console.log('request body is: ',req);

var dropoff_address = req.dropoff_address;
//var dropoff_address = event.request.dropoff_address;
//console.log("The dropoff_address is =>>>>>>>",dropoff_address);

var dropoff_address_city = dropoff_address.city;
var dropoff_address_state = dropoff_address.state;
var dropoff_address_street = dropoff_address.street;
var dropoff_address_zip = dropoff_address.zip_code;


try{
console.log("event is",event);
const estimates = `{
        
    {
  "rating": null,
  "pickup_window_start_time": null,
  "actual_return_time": null,
  "driver_reference_tag": null,
  "contains_alcohol": false,
  "updated_at": "${updated_at}",
  "currency": "USD",
  "estimated_pickup_time": "2021-04-22T18:22:23.454000Z",
  "delivery_verification_image_url": null,
  "order_volume": null,
  "id": 1190573433,
  "dasher_status": "unassigned",
  "estimated_delivery_time": "${estDeliveryTime}",
  "fee": 660,
  "quoted_pickup_time": "2021-04-22T18:22:23.454000Z",
  "dropoff_address": {
    "city": "***********",
    "dasher_parking_details": null,
    "state": "**",
    "street": "308 West 1st Avenue",
    "unit": "undefined",
    "zip_code": "61240"
  },
  "allow_unattended_delivery": false,
  "tip": 0,
  "team_lift_required": false,
  "estimated_return_time": null,
  "batch_id": null,
  "external_store_id": "5455-0",
  "is_return_delivery": false,
  "pickup_instructions": "",
  "dasher": null,
  "status": "scheduled",
  "quoted_delivery_time": "${estDeliveryTime}",
  "actual_pickup_time": null,
  "delivery_window_start_time": null,
  "signature_required": false,
  "delivery_window_end_time": null,
  "pickup_address": {
    "city": "***********",
    "dasher_parking_details": null,
    "external_pickup_zone_id": null,
    "state": "**",
    "street": "681 Avenue Of The Cities",
    "unit": "",
    "zip_code": "61244"
  },
  "barcode_scanning_required": false,
  "submit_platform": "drive_api",
  "store_point": null,
  "delivery_tracking_url": "https://doordash.com/drive/portal/track/f066c791-7aac-4cdf-a589-c89647f2e6b3",
  "external_delivery_id": "f63032e4-726a-4a6e-8ad8-fbb67cc3fd41",
  "customer": {
    "phone_number": "+1 8559731040",
    "first_name": "test",
    "last_name": "loadtest",
    "should_send_notifications": "False",
    "business_name": "",
    "email": "*******************************"
  },
  "return_delivery_id": null,
  "parent_delivery_id": null,
  "order_value": 1758,
  "items": [],
  "cash_on_delivery": null,
  "route_id": null,
  "dropoff_instructions": null,
  "actual_delivery_time": null,
  "signature_image_url": null,
  "quantity": 1,
  "pickup_window_end_time": null,
  "level": "info",
  "message": "DoorDash Response Payload",
  "timestamp": "${timestamp}+00:00"
}

}

}`;

  	let response = {
					statusCode: 200,
					body: estimates
					};

        console.log("Response is", response);
 
           callback(null,response.body) ;
   }
    
    catch(e){
    callback(new Error("Error: No Response got!"));
  }

};